import picker from './picker'

const Picker = {
  install: function (Vue) {
    Vue.component('Picker', picker)
  }
}

export default Picker
